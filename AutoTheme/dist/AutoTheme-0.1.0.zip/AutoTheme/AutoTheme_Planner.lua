AutoTheme = {};
local AT = AutoTheme;
local artObjects = {GREATWORKOBJECT_SCULPTURE = true, GREATWORKOBJECT_LANDSCAPE = true,
    GREATWORKOBJECT_PORTRAIT = true, GREATWORKOBJECT_RELIGIOUS = true};
local validSlots = {};
for row in GameInfo.GreatWork_ValidSubTypes() do
    validSlots[row.GreatWorkSlotType] = validSlots[row.GreatWorkSlotType] or {};
    validSlots[row.GreatWorkSlotType][row.GreatWorkObjectType] = true;
end

local function Flag(value)
    return value == true or value == 1;
end

local function MuseumKind(name)
    local seen = {};
    while name and not seen[name] do
        if name == "BUILDING_MUSEUM_ART" then return "art"; end
        if name == "BUILDING_MUSEUM_ARTIFACT" then return "artifact"; end
        seen[name] = true;
        local replacement = GameInfo.BuildingReplaces[name];
        name = replacement and replacement.ReplacesBuildingType;
    end
    return nil;
end

function AT.SlotKey(city, building, slot)
    return table.concat({city, building, slot}, ":");
end

function AT.ReadSlot(slot)
    local player = Players[Game.GetLocalPlayer()];
    local city = player and player:GetCities():FindID(slot.city);
    if city == nil or city:GetOwner() ~= Game.GetLocalPlayer() then return nil; end
    local buildings = city:GetBuildings();
    if not buildings:HasBuilding(slot.building) then return nil; end
    if buildings:GetNumGreatWorkSlots(slot.building) <= slot.slot then return nil; end
    return buildings:GetGreatWorkInSlot(slot.building, slot.slot);
end

function AT.Collect()
    local result = {museums = {}, slots = {}, works = {}, themed = 0, locked = 0};
    local player = Players[Game.GetLocalPlayer()];
    if player == nil then return result; end
    local metadata = {};
    local duplicates = {};
    for row in GameInfo.Building_GreatWorks() do
        if metadata[row.BuildingType] then duplicates[row.BuildingType] = true; end
        metadata[row.BuildingType] = row;
    end
    for _, city in player:GetCities():Members() do
        local buildings = city:GetBuildings();
        for definition in GameInfo.Buildings() do
            local kind = MuseumKind(definition.BuildingType);
            local rules = metadata[definition.BuildingType];
            if kind and rules and not duplicates[definition.BuildingType] and
                buildings:HasBuilding(definition.Index) and not buildings:IsPillaged(definition.Index) then
                local count = buildings:GetNumGreatWorkSlots(definition.Index);
                if count > 0 then
                    local museum = {key = tostring(city:GetID()) .. ":" .. tostring(definition.Index),
                        city = city:GetID(), building = definition.Index, kind = kind, count = count,
                        slots = {}, fixed = {}, rules = rules, themed = buildings:IsBuildingThemedCorrectly(definition.Index)};
                    local full = true;
                    local supported = count <= 6;
                    for index = 0, count - 1 do
                        local id = buildings:GetGreatWorkInSlot(definition.Index, index);
                        local slotType = buildings:GetGreatWorkSlotType(definition.Index, index);
                        local slotDefinition = GameInfo.GreatWorkSlotTypes[slotType];
                        local slot = {city = city:GetID(), building = definition.Index, slot = index,
                            key = AT.SlotKey(city:GetID(), definition.Index, index), work = id,
                            slotType = slotDefinition and slotDefinition.GreatWorkSlotType, museum = museum};
                        museum.slots[#museum.slots + 1] = slot;
                        if id == -1 then full = false;
                        else
                            local typeID = buildings:GetGreatWorkTypeFromIndex(id);
                            local info = GameInfo.GreatWorks[typeID];
                            if info == nil or (kind == "art" and not artObjects[info.GreatWorkObjectType]) or
                                (kind == "artifact" and info.GreatWorkObjectType ~= "GREATWORKOBJECT_ARTIFACT") then
                                supported = false;
                            else
                                local movable = true;
                                if artObjects[info.GreatWorkObjectType] then
                                    movable = Game.GetCurrentGameTurn() >= buildings:GetTurnFromIndex(id) +
                                        (tonumber(GlobalParameters.GREATWORK_ART_LOCK_TIME) or 10);
                                end
                                result.works[id] = {id = id, object = info.GreatWorkObjectType, era = info.EraType,
                                    person = buildings:GetCreatorNameFromIndex(id), civilization = Game.GetGreatWorkPlayer(id),
                                    movable = movable, home = museum.key};
                            end
                        end
                    end
                    if museum.themed then result.themed = result.themed + 1; end
                    -- Native artifact transfers require both museums to be full.
                    museum.transferable = supported and (kind ~= "artifact" or full) and
                        (Flag(rules.ThemingUniquePerson) or Flag(rules.ThemingSameObjectType) or
                            Flag(rules.ThemingUniqueCivs) or Flag(rules.ThemingSameEras));
                    museum.eligible = museum.transferable and not museum.themed;
                    if not museum.eligible then result.locked = result.locked + 1; end
                    for _, slot in ipairs(museum.slots) do
                        result.slots[slot.key] = slot;
                        local work = result.works[slot.work];
                        if work then
                            work.available = museum.eligible;
                            if museum.eligible and not work.movable then museum.fixed[#museum.fixed + 1] = work; end
                        end
                    end
                    result.museums[#result.museums + 1] = museum;
                end
            end
        end
    end
    table.sort(result.museums, function(a, b) return a.key < b.key; end);
    return result;
end

local function Compatible(group, work, rules)
    if Flag(rules.ThemingSameEras) and work.era == nil then return false; end
    if Flag(rules.ThemingUniquePerson) and (work.person == nil or work.person == "") then return false; end
    if Flag(rules.ThemingUniqueCivs) and (work.civilization == nil or work.civilization < 0) then return false; end
    for _, other in ipairs(group) do
        if Flag(rules.ThemingSameObjectType) and other.object ~= work.object then return false; end
        if Flag(rules.ThemingSameEras) and other.era ~= work.era then return false; end
        if Flag(rules.ThemingUniquePerson) and other.person == work.person then return false; end
        if Flag(rules.ThemingUniqueCivs) and other.civilization == work.civilization then return false; end
    end
    return true;
end

local function FitsSlots(work, museum)
    for _, slot in ipairs(museum.slots) do
        if not (validSlots[slot.slotType] or {})[work.object] then return false; end
    end
    return true;
end

local function FindGroup(museum, inventory, used, budget)
    local group, fixedIDs = {}, {};
    for _, work in ipairs(museum.fixed) do
        if used[work.id] or not Compatible(group, work, museum.rules) then return nil; end
        group[#group + 1] = work; fixedIDs[work.id] = true;
    end
    local pool = {};
    for _, work in pairs(inventory) do
        if work.available and not used[work.id] and not fixedIDs[work.id] and work.movable and FitsSlots(work, museum) then
            pool[#pool + 1] = work;
        end
    end
    -- Keep local works first. Deterministic IDs make repeated clicks stable.
    table.sort(pool, function(a, b)
        if (a.home == museum.key) ~= (b.home == museum.key) then return a.home == museum.key; end
        return a.id < b.id;
    end);
    local nodes = 0;
    local answer;
    local function Search(start)
        nodes = nodes + 1;
        budget.nodes = budget.nodes + 1;
        if nodes > 12000 or budget.nodes > 100000 then return false; end
        if #group == museum.count then
            answer = {}; for i, work in ipairs(group) do answer[i] = work; end
            return true;
        end
        if #group + #pool - start + 1 < museum.count then return false; end
        for i = start, #pool do
            local work = pool[i];
            if Compatible(group, work, museum.rules) then
                group[#group + 1] = work;
                if Search(i + 1) then return true; end
                group[#group] = nil;
            end
        end
        return false;
    end
    Search(1);
    return answer;
end

function AT.Plan(snapshot)
    local desired, targets, used, selected = {}, {}, {}, {};
    local budget = {nodes = 0};
    while true do
        local best;
        for _, museum in ipairs(snapshot.museums) do
            if museum.eligible and not selected[museum.key] and budget.nodes <= 100000 then
                local group = FindGroup(museum, snapshot.works, used, budget);
                if group then
                    local imports = 0;
                    for _, work in ipairs(group) do if work.home ~= museum.key then imports = imports + 1; end end
                    if best == nil or imports < best.imports then best = {museum = museum, group = group, imports = imports}; end
                end
            end
        end
        if best == nil then break; end
        local museum = best.museum;
        selected[museum.key] = true;
        targets[#targets + 1] = museum;
        local remaining = {};
        for _, work in ipairs(best.group) do used[work.id] = true; remaining[work.id] = true; end
        for _, slot in ipairs(museum.slots) do
            if remaining[slot.work] then desired[slot.key] = slot.work; remaining[slot.work] = nil; end
        end
        local ids = {};
        for id in pairs(remaining) do ids[#ids + 1] = id; end
        table.sort(ids);
        local cursor = 1;
        for _, slot in ipairs(museum.slots) do
            if desired[slot.key] == nil then desired[slot.key] = ids[cursor]; cursor = cursor + 1; end
        end
    end
    -- A fixed target order lets each swap lock one more desired slot.
    local slots = {};
    for key in pairs(desired) do slots[#slots + 1] = key; end
    table.sort(slots);
    return {desired = desired, targets = targets, slots = slots};
end

function AT.CanSwap(source, destination, snapshot)
    if source.work == -1 or not source.museum.eligible or not destination.museum.eligible then return false; end
    local work = snapshot.works[source.work];
    local other = snapshot.works[destination.work];
    if work == nil or not work.movable then return false; end
    if not (validSlots[destination.slotType] or {})[work.object] then return false; end
    if other and (not other.movable or not (validSlots[source.slotType] or {})[other.object]) then return false; end
    if other == nil and destination.work ~= -1 then return false; end
    return true;
end
